﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class DestsForm : Form
    {
        public DestsForm()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void DestsForm_Load(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            
            Dests.GetDest();
            dataGridView1.DataSource = Dests.dbDestytojai;
            DAL.GetDalykas();
            comboBox1.DataSource = DAL.dbDalykai;
            comboBox1.DisplayMember = "Dalykas";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Visible=true;
        }



        private void button5_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (addName.Text != "")
            {
                if (Dests.AddDest(addName.Text, addSur.Text, comboBox1.Text))
                {
                    MessageBox.Show("Destytojas sekmingai pridetas", "Sekmingai!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    groupBox1.Visible = false;
                    Dests.GetDest();
                    DAL.GetDalykas();
                }
                else
                {
                    MessageBox.Show("Nepavyko prideti destytojo!", "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Uzpildikyte visus langus!");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminForm adm = new AdminForm();
            adm.Show();
             
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string select = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                DialogResult del = MessageBox.Show("Jus tikrai norit pasalinti sita destytoja?", "Salinimo patvirtinimas", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(del==DialogResult.Yes)
                {
                    Dests.DeleteACC(select);
                    Dests.GetDest();
                    DAL.GetDalykas();
                    dataGridView1.DataSource = Dests.dbDestytojai;
                    MessageBox.Show("Destytojas pasalintas", "Sekmingai!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch
            {
                MessageBox.Show("Klaida salinant");
            }
        }

        private void addName_KeyPress(object sender, KeyPressEventArgs e)
        {
            char l = e.KeyChar;
            if(l< 'A' || l> 'z')
            {
                e.Handled = true;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
