﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    internal class DAL : DbConnection
    {
        static public DataTable dbDalykai = new DataTable();
        static public void GetDalykas()
        {
            try
            {
                DbConnection.msCommand.CommandText = "SELECT * FROM dalykas";
                dbDalykai.Clear();
                DbConnection.msDataAdapter.SelectCommand = DbConnection.msCommand;
                DbConnection.msDataAdapter.Fill(dbDalykai);
            }
            catch
            {
                MessageBox.Show("Klaida gaunat duomenius", "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        static public bool AddDal( string Dalykas)
        {
            try
            {
                DbConnection.msCommand.CommandText = "INSERT INTO dalykas (id_dalykas, Dalykas) VALUES (null,'" + Dalykas + "')";
                if (DbConnection.msCommand.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Klaida pridedant!");
                return false;
            }
        }
    }
}
