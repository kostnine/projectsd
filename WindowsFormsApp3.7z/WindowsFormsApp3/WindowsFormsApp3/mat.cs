﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    internal class mat : DbConnection
    {
        static public DataTable dbMat = new DataTable();
        static public void GetMath()
        {
            try
            {
                DbConnection.msCommand.CommandText = "SELECT * FROM acc WHERE Dalykas = 'Matematika'";
                dbMat.Clear();
                DbConnection.msDataAdapter.SelectCommand = DbConnection.msCommand;
                DbConnection.msDataAdapter.Fill(dbMat);
            }
            catch
            {
                MessageBox.Show("Klaida gaunat duomenius", "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        static public bool AddMath(string Pazymys1, string Pazymys2, string Pazymys3)
        {
            try
            {
                DbConnection.msCommand.CommandText = "INSERT INTO acc (id_account, Pazymys1, Pazymys2, Pazymys3) VALUES (null, '" + Pazymys1 + "', '" + Pazymys2 + "', '" + Pazymys3 + ")";
                if (DbConnection.msCommand.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Klaida pridedant!");
                return false;
            }
        }
        static public void DeleteACC(string del)
        {
            try
            {
                msCommand.CommandText = "DELETE FROM acc WHERE id_account= '" + del + "'";
                msCommand.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Klaida Salint!");

            }
        }
    }


}



