﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    internal class studs
    {
        static public DataTable DbStuden = new DataTable();
        static public void GetStud(string sur)
        {
            try
            {
                // Используйте параметризированный запрос для безопасности
                DbConnection.msCommand.CommandText = "SELECT * FROM acc WHERE id_role = 3 AND Password = @sur";
                // Добавьте параметр к запросу
                DbConnection.msCommand.Parameters.AddWithValue("@sur", sur);

                DbStuden.Clear();
                DbConnection.msDataAdapter.SelectCommand = DbConnection.msCommand;
                DbConnection.msDataAdapter.Fill(DbStuden);
            }
            catch
            {
                MessageBox.Show("Klaida gaunat duomenius", "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
