﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp3
{

    public partial class Form1 : Form
    {
        static public string LoginActive;
        static public string whois;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DbConnection.ConnectionDB();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && textBox2.Text != "")
            {
                Authorization.AuthorizationMethod(textBox1.Text, textBox2.Text);
                switch (Authorization.role)
                {
                    case null:
                        {
                            MessageBox.Show("Toks naudotojas neegzistuoja", "Patikrinkit ivestus duomenius", MessageBoxButtons.OK, MessageBoxIcon.Warning); break;
                        }
                    case "Admin":
                        {
                            LoginActive = textBox1.Text;
                            whois = "Admin";
                            Authorization.User = textBox1.Text;
                            string surname = Authorization.AuthorizationName(textBox1.Text);
                            Authorization.surname = surname;
                            MessageBox.Show(surname + ", sveiki prisijungus i Administratoriaus menu", "Sekmingai!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Hide();
                            AdminForm admin = new AdminForm();
                            admin.Show();
                            break;
                        }
                    case "Destytojas":
                        {
                            LoginActive = textBox1.Text;
                            whois = "Destytojas";
                            Authorization.User = textBox1.Text;
                            string surname = Authorization.AuthorizationName(textBox1.Text);
                            string sur = textBox2.Text;
                            Authorization.surname = surname;
                            sur = textBox2.Text;

                            Destytojas destytojas= new Destytojas(sur);
               
                            MessageBox.Show(surname + ", sveiki prisijungus i Destytojaus menu", "Sekmingai!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Hide();
                            destytojas.Show();
                            break;
                        }
                    case "Studentas":
                        {
                            LoginActive = textBox1.Text;
                            whois = "Studentas";
                            Authorization.User = textBox1.Text;
                            string surname = Authorization.AuthorizationName(textBox1.Text);
                            string sur = textBox2.Text;
                            Authorization.surname = surname;
                            sur = textBox2.Text;

                            Studentas stude = new Studentas(sur);

                            MessageBox.Show(surname + ", sveiki prisijungus i Destytojaus menu", "Sekmingai!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Hide();
                            stude.Show();
                            break;
                        }

                }
               
            }
            else
            {
                MessageBox.Show("Uzpildikyte visus ivedimo langus!", "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
