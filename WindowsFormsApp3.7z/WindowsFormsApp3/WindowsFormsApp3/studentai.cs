﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class studentai : Form
    {
        public studentai()
        {
            InitializeComponent();
            InitializeComboBox();
        }
        private void InitializeComboBox()
        {
            using (MySqlConnection connection = new MySqlConnection(DbConnection.DBConnect))
            {
                connection.Open();

                // Поменяйте "User" на имя вашей таблицы и "ColumnName" на имя вашего столбца
                string query = "SELECT DISTINCT Grupe FROM grupe";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            comboBox1.Items.Add(reader["Grupe"].ToString());
                        }
                    }
                }
            }
        }
        private void studentai_Load(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            groupBox2.Visible = false;

            stud.GetStud();
            dataGridView1.DataSource = stud.dbStud;
            GROUPS.GetGrupe();
            comboBox1.DataSource = GROUPS.dbGrupe;
            comboBox1.DisplayMember = "Grupe";
            DAL.GetDalykas();
            COMBO.DataSource = DAL.dbDalykai;
            COMBO.DisplayMember = "Dalykas";



        }

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (addName.Text != "")
            {
                if (stud.AddStud(addName.Text, addSur.Text, comboBox1.Text, COMBO.Text))
                {
                    MessageBox.Show("Studentas sekmingai pridetas", "Sekmingai!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    groupBox1.Visible = false;
                    stud.GetStud();
                    GROUPS.GetGrupe();
                    DAL.GetDalykas();

                }
                else
                {
                    MessageBox.Show("Nepavyko prideti studento!", "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Uzpildikyte visus langus!");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string select = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                DialogResult del = MessageBox.Show("Jus tikrai norit pasalinti sita studenta?", "Salinimo patvirtinimas", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (del == DialogResult.Yes)
                {
                    stud.DeleteACC(select);
                    stud.GetStud();
                    dataGridView1.DataSource = stud.dbStud;
                    MessageBox.Show("Studentas pasalintas", "Sekmingai!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch
            {
                MessageBox.Show("Klaida salinant");
            }
        }



        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            string inputValue = textBox1.Text;

            if (!string.IsNullOrEmpty(inputValue))
            {
                using (MySqlConnection connection = new MySqlConnection(DbConnection.DBConnect))
                {
                    connection.Open();

                    // Проверка на дублирование
                    string checkDuplicateQuery = $"SELECT COUNT(*) FROM grupe WHERE Grupe = '{inputValue}'";
                    using (MySqlCommand checkDuplicateCommand = new MySqlCommand(checkDuplicateQuery, connection))
                    {
                        int duplicateCount = Convert.ToInt32(checkDuplicateCommand.ExecuteScalar());

                        if (duplicateCount > 0)
                        {
                            MessageBox.Show("Tokia grupe jau egzistuoja!.", "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return; 
                        }
                    }

                 
                    string insertQuery = $"INSERT INTO grupe (Grupe) VALUES ('{inputValue}')";

                    using (MySqlCommand command = new MySqlCommand(insertQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show("Grupe prideta!.");
                    comboBox1.DataSource = null; // Сначала убедитесь, что DataSource сброшен
                    InitializeComboBox();
                }
            }           
            else
            {
                MessageBox.Show("Uzpildikyte langelius!.");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {

            
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }
    }
}
    