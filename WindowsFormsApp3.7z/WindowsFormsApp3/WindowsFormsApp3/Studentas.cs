﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Studentas : Form
    {
        private string sur;
        public Studentas(string sur)
        {
            InitializeComponent();
            this.sur = sur;
        }

        private void Studentas_Load(object sender, EventArgs e)
        {
            studs.GetStud(sur);
            dataGridView1.DataSource = studs.DbStuden;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.Show();
        }
    }
}
