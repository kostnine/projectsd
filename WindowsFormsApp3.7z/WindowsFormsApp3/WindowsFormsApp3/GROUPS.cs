﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    internal class GROUPS : DbConnection
    {
        static public DataTable dbGrupe = new DataTable();
        static public void GetGrupe()
        {
            try
            {
                DbConnection.msCommand.CommandText = "SELECT * FROM grupe";
                dbGrupe.Clear();
                DbConnection.msDataAdapter.SelectCommand = DbConnection.msCommand;
                DbConnection.msDataAdapter.Fill(dbGrupe);
            }
            catch
            {
                MessageBox.Show("Klaida gaunat duomenius", "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        static public bool AddGrupe(string Grupe)
        {
            try
            {
                DbConnection.msCommand.CommandText = "INSERT INTO grupe (idGrupe, Grupe) VALUES (null,'" + Grupe + "')";
                if (DbConnection.msCommand.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Klaida pridedant!");
                return false;
            }
        }
    }
}
