﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    internal class de
    {
        static public DataTable dbDestytojai1 = new DataTable();
        static public MySqlConnection myconnect; 

        static public string CurrentDalykas { get; private set; }
        static public void InitializeConnection()
        {
            myconnect = new MySqlConnection(DbConnection.DBConnect);
            DbConnection.ConnectionDB(); 
        }
        static public void SetDalykas(string dal)
        {
            CurrentDalykas = dal;
        }

        static public void GetDalykasFromDB()
        {
            try
            {
                if (myconnect != null && myconnect.State == ConnectionState.Open)
                {
                    DbConnection.msCommand.CommandText = "SELECT Dalykas FROM acc WHERE Password = @sur LIMIT 1";
                    DbConnection.msDataAdapter.SelectCommand = DbConnection.msCommand;

                    DataTable dalykasTable = new DataTable();
                    DbConnection.msDataAdapter.Fill(dalykasTable);

                    if (dalykasTable.Rows.Count > 0)
                    {
                        CurrentDalykas = dalykasTable.Rows[0]["Dalykas"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Klaida gaunant Dalykas: " + ex.ToString(), "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static public void GetDest()
        {
            try
            {
                if (myconnect != null && myconnect.State == ConnectionState.Open)
                {
                    DbConnection.msCommand.CommandText = "SELECT * FROM acc WHERE id_role = 3 AND Dalykas = @dal";
                    DbConnection.msCommand.Parameters.AddWithValue("@dal", CurrentDalykas);

                    dbDestytojai1.Clear();
                    DbConnection.msDataAdapter.SelectCommand = DbConnection.msCommand;
                    DbConnection.msDataAdapter.Fill(dbDestytojai1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Klaida gaunat duomenius: " + ex.ToString(), "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Очистка параметров их команды после использования
                DbConnection.msCommand.Parameters.Clear();
            }
        }
    }
}

