﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    internal class stud : DbConnection
    {
        static public DataTable dbStud = new DataTable();
        static public void GetStud()
        {
            try
            {
                DbConnection.msCommand.CommandText = "SELECT * FROM acc WHERE id_role = 3";
                dbStud.Clear();
                DbConnection.msDataAdapter.SelectCommand = DbConnection.msCommand;
                DbConnection.msDataAdapter.Fill(dbStud);
            }
            catch
            {
                MessageBox.Show("Klaida gaunat duomenius", "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        static public bool AddStud(string Login, string Password, string Grupe, string Dalykas)
        {
            try
            {
                DbConnection.msCommand.CommandText = "INSERT INTO acc (id_account, Login, Password, id_role, Surname, Grupe, Dalykas) VALUES (null, '" + Login + "', '" + Password + "', 3, '" + Password + "', '" + Grupe +"', '"+ Dalykas +"')";
                if (DbConnection.msCommand.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Klaida pridedant!");
                return false;
            }
        }

        static public void DeleteACC(string del)
        {
            try
            {
                msCommand.CommandText = "DELETE FROM acc WHERE id_account= '" + del + "'";
                msCommand.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Klaida Salint!");

            }
        }
    }
}
