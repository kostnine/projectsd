﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    internal class Dests : DbConnection
    {
        static public DataTable dbDestytojai = new DataTable();
        static public void GetDest()
        {
            try
            {
                DbConnection.msCommand.CommandText = "SELECT * FROM acc WHERE id_role = 2";
                dbDestytojai.Clear();
                DbConnection.msDataAdapter.SelectCommand = DbConnection.msCommand;
                DbConnection.msDataAdapter.Fill(dbDestytojai);
            }
            catch 
            {
                MessageBox.Show("Klaida gaunat duomenius", "Klaida!", MessageBoxButtons.OK, MessageBoxIcon.Error);  
            }

        }
        static public bool AddDest(string Login, string Password, string Dalykas)
        {
            try
            {
               DbConnection.msCommand.CommandText = "INSERT INTO acc (id_account, Login, Password, id_role, Surname, Dalykas) VALUES (null, '" + Login + "', '" + Password + "', 2, '" + Password + "', '" + Dalykas + "')";
                if(DbConnection.msCommand.ExecuteNonQuery()>0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Klaida pridedant!");
                return false;
            }
        }
        static public bool EditSur(int id_account, string Password)
        {
            try
            {
                msCommand.CommandText = "UPDATE acc SET Password= '" + Password + "' WHERE id_account= '" + id_account + "'";
                if (DbConnection.msCommand.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                MessageBox.Show("Klaida redaguojant!");
                return false;
            }
        }
        static public void DeleteACC(string del)
        {
            try
            {
                msCommand.CommandText = "DELETE FROM acc WHERE id_account= '" + del + "'";
                msCommand.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Klaida Salint!");
            
            }
        }
    }
}
