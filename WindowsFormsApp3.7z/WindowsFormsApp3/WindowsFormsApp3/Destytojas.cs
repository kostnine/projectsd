﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp3
{
    public partial class Destytojas : Form
    {
        private string dal;

        public Destytojas(string sur)
        {
            InitializeComponent();
  
            this.dal = GetDalykas(sur);

            LoadData();

        }

        private string GetDalykas(string sur)
        {
            try
            {
                if (DbConnection.ConnectionDB())
                {
            
                    string query = "SELECT Dalykas FROM acc WHERE Password = @sur";
                    DbConnection.msCommand.CommandText = query;
                    DbConnection.msCommand.Parameters.AddWithValue("@sur", sur);

                    using (MySqlDataReader reader = DbConnection.msCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                   
                            return reader["Dalykas"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DbConnection.CloseDB();
            }

            return null;
        }

        private void LoadData()
        {
            try
            {
                if (DbConnection.ConnectionDB())
                {
              
                    string query = "SELECT * FROM acc WHERE Dalykas = @dalykas AND id_role = 3";
                    DbConnection.msCommand.CommandText = query;
                    DbConnection.msCommand.Parameters.AddWithValue("@dalykas", dal);

                    DataTable dataTable = new DataTable();
                    DbConnection.msDataAdapter.Fill(dataTable);

                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DbConnection.CloseDB();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form1 form = new Form1();
            form.Show();

        }

        private void Destytojas_Load(object sender, EventArgs e)
        {

        }

        private void Destytojas_Load_1(object sender, EventArgs e)
        {
      
            comboBox1.Items.Clear();
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                string password = dataGridView1.Rows[i].Cells["Password"].Value.ToString();
                comboBox1.Items.Add(password);
            }

     
            if (comboBox1.Items.Count > 0)
                comboBox1.SelectedIndex = 0;

        
            comboBox2.Items.Clear();
            comboBox2.Items.Add("Pazymys1");
            comboBox2.Items.Add("Pazymys2");
            comboBox2.Items.Add("Pazymys3");
            comboBox2.SelectedIndex = 0;
        }


        private void button2_Click(object sender, EventArgs e)
        {
            // musu passworkdas ir pazymys
            string selectedPassword = comboBox1.SelectedItem.ToString();
            string selectedColumn = comboBox2.SelectedItem.ToString();

   
            string newValue = textBox1.Text;

    
            UpdateDatabase(selectedPassword, selectedColumn, newValue);

            LoadData();
        }

        private void UpdateDatabase(string sur, string columnName, string newValue)
        {
            try
            {
                if (DbConnection.ConnectionDB())
                {
                
                    string query = $"UPDATE acc SET {columnName} = @newValue WHERE Password = @sur AND Dalykas =@dalykas";
                    DbConnection.msCommand.CommandText = query;

                    DbConnection.msCommand.Parameters.AddWithValue("@dalykas", dal);

                    DbConnection.msCommand.Parameters.AddWithValue("@sur", sur);
                    DbConnection.msCommand.Parameters.AddWithValue("@newValue", newValue);

               
                    DbConnection.msCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DbConnection.CloseDB();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

    

