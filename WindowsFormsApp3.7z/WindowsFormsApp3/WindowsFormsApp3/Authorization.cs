﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{ 
    internal class Authorization
    {
        static public string role, surname, User;
        public string Password { get; set; }
        static public void AuthorizationMethod(string login, string password)
        {
            try
            {
                DbConnection.msCommand.CommandText = @"SELECT name_role from sp_role, acc WHERE Login = '" + login + "' and Password ='" + password + "'and acc.id_role=sp_role.id_role";
                object result = DbConnection.msCommand.ExecuteScalar();
                if (result != null)
                {
                    role = result.ToString();
                    User = login;
                }
                else
                {
                    role = null;
                    surname = null;
                }
            }
            catch
            {
                role = User = null;
                MessageBox.Show("Klaida prisijungus");
            
            }

        }
        static public string AuthorizationName(string login)
        {
            try
            {
                DbConnection.msCommand.CommandText = @"SELECT Surname FROM acc WHERE Login = '" + login + "' ";
                object result = DbConnection.msCommand.ExecuteScalar();
                surname = result.ToString();
                return surname;
            }
            catch
            {
                return null;
            }
        }
    }
}
