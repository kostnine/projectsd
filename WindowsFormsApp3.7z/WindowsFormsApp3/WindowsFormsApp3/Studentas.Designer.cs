﻿namespace WindowsFormsApp3
{
    partial class Studentas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.id_account = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Login = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Grupe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dalykas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pazymys1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pazymys2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pazymys3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button8 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Highlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id_account,
            this.Login,
            this.Password,
            this.Grupe,
            this.Dalykas,
            this.Pazymys1,
            this.Pazymys2,
            this.Pazymys3});
            this.dataGridView1.Location = new System.Drawing.Point(1, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(744, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(71, 65);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(8, 8);
            this.dataGridView2.TabIndex = 1;
            // 
            // id_account
            // 
            this.id_account.DataPropertyName = "id_account";
            this.id_account.HeaderText = "Column1";
            this.id_account.Name = "id_account";
            this.id_account.ReadOnly = true;
            this.id_account.Visible = false;
            // 
            // Login
            // 
            this.Login.DataPropertyName = "Login";
            this.Login.HeaderText = "Vardas";
            this.Login.Name = "Login";
            this.Login.ReadOnly = true;
            // 
            // Password
            // 
            this.Password.DataPropertyName = "Password";
            this.Password.HeaderText = "Pavarde";
            this.Password.Name = "Password";
            this.Password.ReadOnly = true;
            // 
            // Grupe
            // 
            this.Grupe.DataPropertyName = "Grupe";
            this.Grupe.HeaderText = "Grupe";
            this.Grupe.Name = "Grupe";
            this.Grupe.ReadOnly = true;
            // 
            // Dalykas
            // 
            this.Dalykas.DataPropertyName = "Dalykas";
            this.Dalykas.HeaderText = "Dalykas";
            this.Dalykas.Name = "Dalykas";
            this.Dalykas.ReadOnly = true;
            // 
            // Pazymys1
            // 
            this.Pazymys1.DataPropertyName = "Pazymys1";
            this.Pazymys1.HeaderText = "Pazymys uz 1 kontrolini darba";
            this.Pazymys1.Name = "Pazymys1";
            this.Pazymys1.ReadOnly = true;
            // 
            // Pazymys2
            // 
            this.Pazymys2.DataPropertyName = "Pazymys2";
            this.Pazymys2.HeaderText = "Pazymys uz 2 kontrolini darba";
            this.Pazymys2.Name = "Pazymys2";
            this.Pazymys2.ReadOnly = true;
            // 
            // Pazymys3
            // 
            this.Pazymys3.DataPropertyName = "Pazymys3";
            this.Pazymys3.HeaderText = "Pazymys uz egzamina";
            this.Pazymys3.Name = "Pazymys3";
            this.Pazymys3.ReadOnly = true;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button8.Location = new System.Drawing.Point(594, 371);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(151, 38);
            this.button8.TabIndex = 10;
            this.button8.Text = "Grizti";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // Studentas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Studentas";
            this.Text = "Studentas";
            this.Load += new System.EventHandler(this.Studentas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_account;
        private System.Windows.Forms.DataGridViewTextBoxColumn Login;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.DataGridViewTextBoxColumn Grupe;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dalykas;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pazymys1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pazymys2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pazymys3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button8;
    }
}